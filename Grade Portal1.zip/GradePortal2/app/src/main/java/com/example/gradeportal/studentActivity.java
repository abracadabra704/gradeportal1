package com.example.gradeportal;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.TextView;

public class studentActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student);
        TextView user,sub,grade;


        user =findViewById(R.id.textView8);
        sub = findViewById(R.id.textView9);
        grade =findViewById(R.id.textView10);
        SharedPreferences sp = getApplicationContext().getSharedPreferences("MyUserPrefs", Context.MODE_PRIVATE);
        String user1=sp.getString("username", "");
        String sub1=sp.getString("subject", "");
        String grade1=sp.getString("grade", "");

        user.setText(user1);
        sub.setText(sub1);
        grade.setText(grade1);
    }
}