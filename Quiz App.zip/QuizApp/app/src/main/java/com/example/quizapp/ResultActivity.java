package com.example.quizapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import org.w3c.dom.Text;

public class ResultActivity extends AppCompatActivity {
    TextView grade,finalscore;
    Button rretry;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);
        grade=(TextView)findViewById(R.id.grade);
        finalscore=(TextView)findViewById(R.id.yourscore);
        rretry=(Button)findViewById(R.id.retry);

        Bundle bundle = getIntent().getExtras();
        int score=bundle.getInt("Final Score");
        finalscore.setText("You scored "   + score + " out of " + Quiz.questions.length);
        if (score==10){
            grade.setText("Excellent");
        }else if (score==9){
            grade.setText("Outstanding");
        }else if(score==8){
            grade.setText("Good");
        }else{
            grade.setText("Better luck next time");
        }

        rretry.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity( new Intent(ResultActivity.this,QuizActivity.class));
                ResultActivity.this.finish();
            }
        });
    }
}