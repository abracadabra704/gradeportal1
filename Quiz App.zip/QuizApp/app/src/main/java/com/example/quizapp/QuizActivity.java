package com.example.quizapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class QuizActivity extends AppCompatActivity {
    private TextView ascoreview,aquestion;
    private ImageView aimageview;
    private Button atruebutton,afalsebutton;

    private boolean aanswer;
    private int ascore=0, aquestionnumber=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiz);
        ascoreview= (TextView)findViewById(R.id.points);
        aimageview= (ImageView) findViewById(R.id.images);
        aquestion= (TextView)findViewById(R.id.questions);
        atruebutton= (Button) findViewById(R.id.truebtn);
        afalsebutton= (Button) findViewById(R.id.falsebtn);

        atruebutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (aanswer==true){
                    ascore++;
                    updatescore(ascore);
                    if (aquestionnumber==Quiz.questions.length){
                    Intent intent=new Intent(QuizActivity.this,ResultActivity.class);
                    Bundle bundle= new Bundle();
                    bundle.putInt("Final Score", ascore);
                    intent.putExtras(bundle);
                    QuizActivity.this.finish();
                    startActivity(intent);
                }else {
                    updatequestion();

                }
            }
                else{
                    if (aquestionnumber==Quiz.questions.length){
                        Intent intent=new Intent(QuizActivity.this,ResultActivity.class);
                        Bundle bundle= new Bundle();
                        bundle.putInt("Final Score", ascore);
                        intent.putExtras(bundle);
                        QuizActivity.this.finish();
                        startActivity(intent);
                    }else {
                        updatequestion();

                    }

                }}
        });
        afalsebutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (aanswer==false){
                    ascore++;
                    updatescore(ascore);
                    if (aquestionnumber==Quiz.questions.length){
                        Intent intent=new Intent(QuizActivity.this,ResultActivity.class);
                        Bundle bundle= new Bundle();
                        bundle.putInt("Final Score", ascore);
                        intent.putExtras(bundle);
                        QuizActivity.this.finish();
                        startActivity(intent);
                    }else {
                        updatequestion();

                    }
                }
                else{
                    if (aquestionnumber==Quiz.questions.length){
                        Intent intent=new Intent(QuizActivity.this,ResultActivity.class);
                        Bundle bundle= new Bundle();
                        bundle.putInt("Final Score", ascore);
                        intent.putExtras(bundle);
                        QuizActivity.this.finish();
                        startActivity(intent);
                    }else {
                        updatequestion();

                    }

                }}
        });
    }
    private void updatequestion(){

        aimageview.setImageResource(Quiz.images[aquestionnumber]);
        aquestion.setText(Quiz.questions[aquestionnumber]);
        aanswer= Quiz.answers[aquestionnumber];
        aquestionnumber++;

    }

    public void updatescore(int point){
        ascoreview.setText("" + ascore);
    }
}