package com.example.quizapp;

public class Quiz {
    public static String[] questions = new String[]{
            "1. Virtual private networks permit users to create permanent virtual circuits, or tunnels, through the Internet.",
            "2. Connectionless routing sets up a TCP connection, or virtual circuit between a sender and receiver.",
            "3. Peering means that a national ISP does not charge another national ISP to transmit its messages. ",
            "4. The rise of the Internet has increased significantly the potential vulnerability of an organization's assets.",
            "5. Cloud (as in cloud architecture) means that the design for the common carrier's network comes from satellite networks above the clouds.",
            "6. Security on a network not only means being able to prevent a hacker from breaking into your computer but also includes being able to recover from temporary service problems or from natural disasters.",
            "7. National Internet service providers connect together and exchange data at Network Access Points.",
            "8. A threat to the data communications network is any potential adverse occurrence that can do harm, interrupt the systems using the network, or cause a monetary loss to the organization.",
            "9. Companies have learned that threats from hacking from its own employees occur about as often as by outsiders.",
            "10. A NAT proxy server uses an address table to translate private IP addresses used inside the organization into proxy data link layer addressed used on the Internet.",



    };
    public static int[] images = new int[]{
            R.drawable.pic1,R.drawable.pic2,R.drawable.pic3,R.drawable.pic4,R.drawable.pic5,R.drawable.pic6,R.drawable.pic7,R.drawable.pic8,R.drawable.pic9,R.drawable.pic10,
    };

    public static boolean[] answers = new boolean[]{
            true,false,true,true,false,true,true,true,true,true
    };
}
