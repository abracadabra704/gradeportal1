package com.example.gradeportal;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class DBHelperT extends SQLiteOpenHelper {
    public static String DBNAME= "LoginT.db";

    public DBHelperT(Context context) {

        super(context, "LoginT.db", null, 1);
    }


    @Override
    public void onCreate(SQLiteDatabase Mydb1) {
        Mydb1.execSQL("create Table usersT(username TEXT primary key , password TEXT)");



    }

    @Override
    public void onUpgrade(SQLiteDatabase Mydb1, int oldVersion, int newVersion) {
        Mydb1.execSQL("drop table if exists usersT");



    }



    public Boolean insertData1(String username, String password){
        SQLiteDatabase Mydb1=this.getWritableDatabase();
        ContentValues contentValues= new ContentValues();
        contentValues.put("username",username);
        contentValues.put("password",password);


        long result= Mydb1.insert("usersT", null,contentValues);
        if (result==-1) return false;
        else
            return true;
    }
    public Boolean checkusername1 (String username){
        SQLiteDatabase Mydb1= this.getWritableDatabase();
        Cursor cursor= Mydb1.rawQuery("Select * from usersT where username = ?", new String [] {username});
        if(cursor.getCount()>0)
            return true;
        else
            return false;
    }
    public Boolean checkusernamepassword1(String username, String password){
        SQLiteDatabase Mydb1= this.getWritableDatabase();
        Cursor cursor = Mydb1. rawQuery( "Select * from usersT where username = ? and password= ?",new String [] {username,password});
        if(cursor.getCount()>0)
            return true;
        else
            return false;
    }


}
