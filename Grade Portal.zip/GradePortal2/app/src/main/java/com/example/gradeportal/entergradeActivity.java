package com.example.gradeportal;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class entergradeActivity extends AppCompatActivity {
    Button insert, update;
    EditText subject, username,username1,  grade;
    DBHelper DB;
    DatabaseHelper db;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_entergrade);

      username=(EditText)findViewById(R.id.txtusername1);
      subject=(EditText)findViewById(R.id.txtsubject);
      grade=(EditText)findViewById(R.id.txtgrade);
        insert=(Button) findViewById(R.id.btninsert);
        update=(Button) findViewById(R.id.btnupdate);
        DB= new DBHelper(this);
        db= new DatabaseHelper(this);

        insert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String user = username.getText().toString();
                String sub = subject.getText().toString();
                String grades = grade.getText().toString();

                if(user.equals("")|| sub.equals("")||grades.equals(""))
                    Toast.makeText(entergradeActivity.this, "Please enter all the fields", Toast.LENGTH_SHORT).show();
                else{
                        Boolean checkuser1 = DB.checkusername1(user);
                        if(checkuser1) {
                            Boolean insert = db.insertgrade(user, sub,grades);
                            if (insert){
                                Toast.makeText(entergradeActivity.this, "Registered Successfully", Toast.LENGTH_SHORT).show();

                            }
                            else
                            {
                                Toast.makeText(entergradeActivity.this, "Already entered grade", Toast.LENGTH_SHORT).show();
                            }
                        }
                        else{
                            Toast.makeText(entergradeActivity.this, "User doesn't exist", Toast.LENGTH_SHORT).show();
                        }

                }


            }
        });

    }

}