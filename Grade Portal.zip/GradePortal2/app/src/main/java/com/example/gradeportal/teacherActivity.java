package com.example.gradeportal;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class teacherActivity extends AppCompatActivity {
    EditText code;
    Button button;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_teacher);

        code=(EditText)findViewById(R.id.txtcode);
        button=(Button)findViewById(R.id.enter);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(code.getText().toString().equals(""))
                    Toast.makeText(teacherActivity.this, "Invalid input", Toast.LENGTH_SHORT).show();

                    else {
                        if(code.getText().toString().equals("admin")){
                            Toast.makeText(teacherActivity.this, "Verification Successful", Toast.LENGTH_SHORT).show();
                            Intent intent= new Intent( teacherActivity.this, RegisterT2Activity.class);
                            startActivity(intent);


                         }
                            else
                {
                    Toast.makeText(teacherActivity.this, "Log in failed", Toast.LENGTH_SHORT).show();
                }
                    }

                }
        }
        );
    }
}