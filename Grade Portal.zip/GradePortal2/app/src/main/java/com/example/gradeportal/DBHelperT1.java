package com.example.gradeportal;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class DBHelperT1 extends SQLiteOpenHelper {
    public static final String dbNAME= "LoginT1.db";

    public DBHelperT1(Context context) {
        super(context, "LoginT1",null , 1);
    }

    @Override
    public void onCreate(SQLiteDatabase Mydb) {
        Mydb.execSQL("create Table usersT1(username TEXT primary key , password TEXT)");

    }

    @Override
    public void onUpgrade(SQLiteDatabase Mydb, int oldVersion, int newVersion) {
        Mydb.execSQL("drop table if exists usersT1");

    }

    public Boolean insertData(String username, String password){
        SQLiteDatabase Mydb=this.getWritableDatabase();
        ContentValues contentValues= new ContentValues();
        contentValues.put("username",username);
        contentValues.put("password",password);


        long result= Mydb.insert("usersT1", null,contentValues);
        if (result==-1) return false;
        else
            return true;
    }
    public Boolean checkusername (String username){
        SQLiteDatabase Mydb= this.getWritableDatabase();
        Cursor cursor= Mydb.rawQuery("Select * from usersT1 where username = ?", new String [] {username});
        if(cursor.getCount()>0)
            return true;
        else
            return false;
    }
    public Boolean checkusernamepassword(String username, String password){
        SQLiteDatabase Mydb= this.getWritableDatabase();
        Cursor cursor = Mydb. rawQuery( "Select * from usersT1 where username = ? and password= ?",new String [] {username,password});
        if(cursor.getCount()>0)
            return true;
        else
            return false;
    }


}

