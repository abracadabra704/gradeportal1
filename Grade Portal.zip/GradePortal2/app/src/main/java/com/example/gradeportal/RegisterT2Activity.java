package com.example.gradeportal;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class RegisterT2Activity extends AppCompatActivity {
    EditText username,password,repassword;
    Button sign;
    DBHelperT1 DB;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register_t2);

        username=(EditText) findViewById(R.id.inputusernameT2);
        password=(EditText) findViewById(R.id.inputpassT2);
        repassword=(EditText) findViewById(R.id.inputrepass2);
        sign=(Button) findViewById(R.id.signuprT1);
        DB= new DBHelperT1(this);
        TextView btn= findViewById(R.id.signupT1);


        sign.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String user = username.getText().toString();
                String pass = password.getText().toString();
                String repass = repassword.getText().toString();





                if(user.equals("")|| pass.equals("")||repass.equals(""))
                    Toast.makeText(RegisterT2Activity.this, "Please enter all the fields", Toast.LENGTH_SHORT).show();
                else{
                    if(pass.equals(repass)){
                        Boolean checkuser = DB.checkusername(user);
                        if(!checkuser) {
                            Boolean insert = DB.insertData(user, pass);
                            if (insert){
                                Toast.makeText(RegisterT2Activity.this, "Registered Successfully", Toast.LENGTH_SHORT).show();
                                Intent intent = new Intent(getApplicationContext(),LoginTActivity.class);
                                startActivity(intent);


                            }
                            else
                            {
                                Toast.makeText(RegisterT2Activity.this, "Registration Failed", Toast.LENGTH_SHORT).show();
                            }
                        }
                        else{
                            Toast.makeText(RegisterT2Activity.this, "User already exist", Toast.LENGTH_SHORT).show();
                        }
                    }
                    else{
                        Toast.makeText(RegisterT2Activity.this, "Incorrect password", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });


        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(RegisterT2Activity.this, LoginTActivity.class));
            }
        });


    }}
